﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassFarm
{
    public class Duck
    {
        public void Animal(string animal)
        {
            Console.WriteLine($"I am a " + animal);
        }

        public void Name(string name)
        {
            Console.WriteLine($"My name is " + name);
        }

        public void Sound(string sound)
        {
            Console.WriteLine($"I say " + sound);
        }

        public void Produce(string produce)
        {
            Console.WriteLine($"I provide " + produce);
        }
    }
}
