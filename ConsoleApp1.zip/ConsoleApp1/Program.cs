using System;
using ClassFarm;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)

        {
                Console.WriteLine("Choose an animal.For 'horse' enter '1'.For 'duck' enter '2'.For 'sheep' enter '3'.For 'pig' enter '4'.");
                string animal = Console.ReadLine();
                if (animal == "1")
                {
                    Horse horse = new Horse();
                    horse.Animal("horse");
                    Console.WriteLine("Enter the horse's name.");
                    horse.Name(Console.ReadLine());
                    horse.Sound("\"naey\"");
                    horse.Produce("transportation");
                }
                if (animal == "2")
                {
                    Duck duck = new Duck();
                    duck.Animal("duck");
                    Console.WriteLine("Enter the duck's name.");
                    duck.Name(Console.ReadLine());
                    duck.Sound("\"quack\"");
                    duck.Produce("eggs");
                }
                if (animal == "3")
                {
                    Sheep sheep = new Sheep();
                    sheep.Animal("sheep");
                    Console.WriteLine("Enter the horse's name.");
                    sheep.Name(Console.ReadLine());
                    sheep.Sound("\"bah-ah-ah\"");
                    sheep.Produce("wool");
                }
                if (animal == "4")
                {
                    Pig pig = new Pig();
                    pig.Animal("pig");
                    Console.WriteLine("Enter the horse's name.");
                    pig.Name(Console.ReadLine());
                    pig.Sound("\"oink\"");
                    pig.Produce("bacon");
                }
                Console.ReadKey();
        }
    }
}
